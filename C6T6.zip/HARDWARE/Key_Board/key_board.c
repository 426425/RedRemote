#include "key_board.h"
#include "delay.h"

extern uint8_t key_flag; //�ж��Ƿ��а������²���ӡ������ֵ

void KeyBoard_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	/* Enable KeyGPIO port clock */
	RCC_APB2PeriphClockCmd(COLUMN_KEY_GPIO_CLK|ROW_KEY_GPIO_CLK,ENABLE);
	
	/* Column Key GPIO Configuration */
	GPIO_InitStruct.GPIO_Pin = C1_PIN|C2_PIN|C3_PIN|C4_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(COLUMN_KEY_GPIO_PORT,&GPIO_InitStruct);
	
	/* Row Key GPIO Configuration */
	GPIO_InitStruct.GPIO_Pin = R1_PIN|R2_PIN|R3_PIN|R4_PIN;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(ROW_KEY_GPIO_PORT,&GPIO_InitStruct);
	
	GPIO_SetBits(COLUMN_KEY_GPIO_PORT,C1_PIN|C2_PIN|C3_PIN|C4_PIN);
	GPIO_ResetBits(ROW_KEY_GPIO_PORT,R1_PIN|R2_PIN|R3_PIN|R4_PIN);
}


char Key_scan(void)
{
	uint16_t temp = 0;
	char Key_val = 0;
	
	/*************************** Column 1 ***************************/
	GPIO_SetBits(COLUMN_KEY_GPIO_PORT,C1_PIN);
	GPIO_ResetBits(COLUMN_KEY_GPIO_PORT,C2_PIN|C3_PIN|C4_PIN);
	
	temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
	
	if(temp != 0x0000)
	{
		delay_ms(5);
		temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		if(temp != 0x0000)
		{
			key_flag = 1;
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
			switch(temp)
			{
				case 0x1000: Key_val = '1';break;
				case 0x2000: Key_val = '4';break;
				case 0x4000: Key_val = '7';break;
				case 0x8000: Key_val = '*';break;
			}
			printf("Key_val:%c",Key_val);
		}
		while(temp != 0x0000)
		{
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		}
	}
	
	/*************************** Column 2 ***************************/
	GPIO_SetBits(COLUMN_KEY_GPIO_PORT,C2_PIN);
	GPIO_ResetBits(COLUMN_KEY_GPIO_PORT,C1_PIN|C3_PIN|C4_PIN);
	
	temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
	
	if(temp != 0x0000)
	{
		delay_ms(5);
		temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		if(temp != 0x0000)
		{
			key_flag = 1;
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
			switch(temp)
			{
				case 0x1000: Key_val = '2';break;
				case 0x2000: Key_val = '5';break;
				case 0x4000: Key_val = '8';break;
				case 0x8000: Key_val = '0';break;
			}
			printf("Key_val:%c",Key_val);
		}
		while(temp != 0x0000)
		{
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		}
	}
	
	/*************************** Column 3 ***************************/
	GPIO_SetBits(COLUMN_KEY_GPIO_PORT,C3_PIN);
	GPIO_ResetBits(COLUMN_KEY_GPIO_PORT,C1_PIN|C2_PIN|C4_PIN);
	
	temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
	
	if(temp != 0x0000)
	{
		delay_ms(5);
		temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		if(temp != 0x0000)
		{
			key_flag = 1;
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
			switch(temp)
			{
				case 0x1000: Key_val = '3';break;
				case 0x2000: Key_val = '6';break;
				case 0x4000: Key_val = '9';break;
				case 0x8000: Key_val = '#';break;
			}
			printf("Key_val:%c",Key_val);
		}
		while(temp != 0x0000)
		{
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		}
	}
	
	/*************************** Column 4 ***************************/
	GPIO_SetBits(COLUMN_KEY_GPIO_PORT,C4_PIN);
	GPIO_ResetBits(COLUMN_KEY_GPIO_PORT,C1_PIN|C2_PIN|C3_PIN);
	
	temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
	
	if(temp != 0x0000)
	{
		delay_ms(5);
		temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		if(temp != 0x0000)
		{
			key_flag = 1;
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
			switch(temp)
			{
				case 0x1000: Key_val = 'A';break;
				case 0x2000: Key_val = 'B';break;
				case 0x4000: Key_val = 'C';break;
				case 0x8000: Key_val = 'D';break;
			}
			printf("Key_val:%c",Key_val);
		}
		while(temp != 0x0000)
		{
			temp = GPIO_ReadInputData(ROW_KEY_GPIO_PORT) & 0xF000;
		}
	}
	
	return Key_val;
}

/*********************************************END OF FILE*********************************************/
