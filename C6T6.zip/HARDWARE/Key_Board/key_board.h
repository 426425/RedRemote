#ifndef __KEY_BOARD_H
#define __KEY_BOARD_H

#include "stm32f10x.h"

#define COLUMN_KEY_GPIO_PORT				GPIOA
#define COLUMN_KEY_GPIO_CLK					RCC_APB2Periph_GPIOA
#define C1_PIN								GPIO_Pin_8
#define C2_PIN								GPIO_Pin_5
#define C3_PIN								GPIO_Pin_6
#define C4_PIN								GPIO_Pin_7



#define ROW_KEY_GPIO_PORT					GPIOB
#define ROW_KEY_GPIO_CLK					RCC_APB2Periph_GPIOB
#define R1_PIN								GPIO_Pin_12
#define R2_PIN								GPIO_Pin_13
#define R3_PIN								GPIO_Pin_14
#define R4_PIN								GPIO_Pin_15

 
void KeyBoard_Init(void);
char Key_scan(void);

#endif	/* __KEYBOARD_H */
