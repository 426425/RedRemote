#ifndef __MYRTC_H
#define __MYRTC_H
#include "stm32f10x.h"

//��ʱRTCʱ�ӽṹ��
struct RTC_CLOCK
{
		u32 year;
	  u32 mon;
	  u32 day;
		u32 hour;
		u32 min;
	  u32 sec;
		u32 week;
};
extern struct RTC_CLOCK rtc_clock; 
extern uint16_t New_RTC[6];

extern u8 Open_Auto_Air;
extern u8 flashTim;
//��������
void RTC_Init(void);
u8 RTC_GetYearState(u32 year);
void RTC_GetTime(u32 sec);
void RTC_GetWeek(u32 sec);
void RTC_SetTime(u32 year,u32 mon,u32 day,u32 hour,u32 min,u32 sec);
void STM32_SetPriority(IRQn_Type IRQn, uint32_t preemption, uint32_t subpriority);

#endif
