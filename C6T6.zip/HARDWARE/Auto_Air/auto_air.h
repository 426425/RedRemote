#ifndef __AUTO_AIR
#define __AUTO_AIR	 
#include "sys.h"

extern uint8_t Auto_Time[7][7];
extern u8 Open_Auto_Air;
//void Set_Class_Tlab(u8 Value);

#endif
